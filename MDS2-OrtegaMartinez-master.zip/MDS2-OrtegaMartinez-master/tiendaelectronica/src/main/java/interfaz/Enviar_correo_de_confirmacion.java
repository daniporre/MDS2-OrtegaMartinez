package interfaz;

public class Enviar_correo_de_confirmacion {
	public Compra_Encargado_de_compras_ _compra_Encargado_de_compras_;
}