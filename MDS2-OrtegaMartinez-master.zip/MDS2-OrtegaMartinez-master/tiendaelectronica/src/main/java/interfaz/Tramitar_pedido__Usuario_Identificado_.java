package interfaz;

public class Tramitar_pedido__Usuario_Identificado_ {
	public Carrito__Usuario_registrado_ _carrito__Usuario_registrado_;
	public Enviar_correo_de_confirmación _enviar_correo_de_confirmación;
	public Correo _tramitar_pedido__Usuario_identificado_;

	public boolean enviarCorreoConfirmacion() {
		throw new UnsupportedOperationException();
	}
}