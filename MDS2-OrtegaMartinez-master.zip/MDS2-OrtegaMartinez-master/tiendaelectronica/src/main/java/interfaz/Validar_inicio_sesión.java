package interfaz;

public class Validar_inicio_sesión {
	public Iniciar_sesión _iniciar_sesión;
}