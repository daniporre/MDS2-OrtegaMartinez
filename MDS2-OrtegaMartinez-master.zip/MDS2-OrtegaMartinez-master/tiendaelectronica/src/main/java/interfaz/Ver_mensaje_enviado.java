package interfaz;

public class Ver_mensaje_enviado {
	private Label _mensajeEnviadoTitulo;
	private Label _asunto;
	private Label _asuntoL;
	private Label _mensajeL;
	private TextView _mensajeTV;
	private Button _aceptar;
	public Mensajes_enviados _mensajes_enviados;

	public void aceptar() {
		throw new UnsupportedOperationException();
	}
}