package interfaz;

public class Iniciar_sesión {
	private Label _titulo;
	private Label _mail;
	private Label _contraseña;
	private TextField _mailTF;
	private TextField _contraseñaTF;
	private Button _recuperarContraseña;
	private Button _iniciarSesion;
	public Crear_cuenta_Iniciar_sesión _crear_cuenta_Iniciar_sesión;
	public Recuperar_contraseña _recuperar_contraseña;
	public Validar_inicio_sesión _validar_inicio_sesión;

	public boolean validarInicioSesion() {
		throw new UnsupportedOperationException();
	}

	public void recuperarContraseña() {
		throw new UnsupportedOperationException();
	}

	public void iniciarSesion() {
		throw new UnsupportedOperationException();
	}
}