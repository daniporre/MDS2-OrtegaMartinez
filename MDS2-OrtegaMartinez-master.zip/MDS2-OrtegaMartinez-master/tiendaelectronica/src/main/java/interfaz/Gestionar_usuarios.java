package interfaz;

public class Gestionar_usuarios {
	private Panel _crearNuevoUsuario;
	private Panel _editarContraseñaUsuario;
	public Administrador _administrador;
	public Crear_usuario _crear_usuario;
	public Cambiar_contraseña_a_usuario _cambiar_contraseña_a_usuario;
}