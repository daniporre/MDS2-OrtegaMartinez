package interfaz;

public class Modificar_datos {
	private event _guardar_cambios;
	public Modificar_producto _modificar_producto;

	public void Guardar_cambios() {
		throw new UnsupportedOperationException();
	}
}