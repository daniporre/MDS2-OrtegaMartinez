package interfaz;

public class Actualizar_lista_de_compras {
	public Ver_listado_de_compras _ver_listado_de_compras;
}