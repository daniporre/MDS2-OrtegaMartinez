package interfaz;

public class Correo__Administrador_ extends Correo__General_ {
	public Administrador _administrador;
}