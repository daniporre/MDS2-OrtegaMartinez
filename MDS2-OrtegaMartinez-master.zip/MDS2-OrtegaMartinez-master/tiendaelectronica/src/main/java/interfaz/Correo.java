package interfaz;

import basededatos.iCorreo;

public class Correo {
	public Enviar_correo _correo;
	public Tramitar_pedido__Usuario_Identificado_ _correo;
	public iCorreo _iCorreo;
	public Enviar_correo_de_confirmación _enviar_correo_de_confirmación;
}