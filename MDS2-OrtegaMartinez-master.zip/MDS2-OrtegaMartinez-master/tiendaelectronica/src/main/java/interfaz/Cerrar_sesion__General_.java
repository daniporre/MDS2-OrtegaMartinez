package interfaz;

public class Cerrar_sesion__General_ {
	public Común_gestores _común_gestores;
}