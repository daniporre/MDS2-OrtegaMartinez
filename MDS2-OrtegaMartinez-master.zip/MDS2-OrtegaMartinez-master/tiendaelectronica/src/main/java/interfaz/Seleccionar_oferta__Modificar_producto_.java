package interfaz;

public class Seleccionar_oferta__Modificar_producto_ {
	private event _guardar_cambios;
	public Modificar_producto _modificar_producto;

	public void Guardar_cambios() {
		throw new UnsupportedOperationException();
	}
}