package interfaz;

import java.util.Vector;
import interfaz.Compra;

public class Ver_listado_de_compras__Empresa_de_transportes_ {
	public Ver_listado_de_compras__Empresa_transportes_ _ver_listado_de_compras__Empresa_transportes_;
	public Vector<Compra> _list_Compra = new Vector<Compra>();
}