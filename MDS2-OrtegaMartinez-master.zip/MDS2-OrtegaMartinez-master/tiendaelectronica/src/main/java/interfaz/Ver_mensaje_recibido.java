package interfaz;

public class Ver_mensaje_recibido {
	private Label _responderMensajeTitulo;
	private Label _asuntoL;
	private TextField _asuntoTF;
	private Label _mensajeL;
	private TextView _mensajeTV;
	private Button _aceptar;
	private Button _responderMensaje;
	public Mensajes_recibidos _mensajes_recibidos;
	public Responder_mensaje _responder_mensaje;

	public void responderMensaje() {
		throw new UnsupportedOperationException();
	}

	public void aceptar() {
		throw new UnsupportedOperationException();
	}
}