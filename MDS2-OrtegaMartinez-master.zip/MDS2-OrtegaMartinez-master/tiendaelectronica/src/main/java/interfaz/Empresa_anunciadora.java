package interfaz;

import basededatos.iEmpresa_anunciadora;

public class Empresa_anunciadora {
	public iEmpresa_anunciadora _iEmpresa_anunciadora;
	public Clicar_en_anuncio _clicar_en_anuncio;
}