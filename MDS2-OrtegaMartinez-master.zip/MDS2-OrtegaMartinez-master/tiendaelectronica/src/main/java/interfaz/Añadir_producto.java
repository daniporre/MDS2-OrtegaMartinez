package interfaz;

public class Añadir_producto {
	private TextField _nombreTF;
	private TextField _precio;
	private TextField _marca;
	private Label _oferta;
	private ComboBox _ofertaCB;
	private Button _guardarCambios;
	private Image _imagen;
	private Image _imagen2;
	private Image _imagen3;
	private Image _imagen4;
	private TextView _descripcion;
	private Label _descripcionL;
	public Administrador _administrador;
	public Añadir_fotos _añadir_fotos;
	public Seleccionar_oferta__Añadir_producto_ _seleccionar_oferta__Añadir_producto_;
	public Añadir_descripción_de_producto _añadir_descripción_de_producto;

	public void guardarCambios() {
		throw new UnsupportedOperationException();
	}
}