package interfaz;

public class Recuperar_contraseña {
	public Iniciar_sesión _iniciar_sesión;
	public Correo_de_verificación _correo_de_verificación;

	public boolean enviarCorreoRecuperacion() {
		throw new UnsupportedOperationException();
	}
}