package interfaz;

public class Ver_categoría extends Visualizar_producto {
	private Button _categoria;
	public Categorías _categorías;

	public void mostrarCategoria() {
		throw new UnsupportedOperationException();
	}
}