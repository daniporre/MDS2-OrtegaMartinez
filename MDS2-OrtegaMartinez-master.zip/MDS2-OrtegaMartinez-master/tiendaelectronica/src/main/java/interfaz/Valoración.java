package interfaz;

public class Valoración {
	private Image _imagen;
	public Valoraciones _valoraciones;
	public Visualizar_producto__desde_valoración_ _visualizar_producto__desde_valoración_;
}