package interfaz;

public class Ver_listado_de_compras {
	private Button _actualizarListaCompras;
	public Común_gestores _común_gestores;
	public Pedidos _pedidos;
	public Actualizar_lista_de_compras _actualizar_lista_de_compras;

	public void actualizarListaCompras() {
		throw new UnsupportedOperationException();
	}
}