package interfaz;

import java.util.Vector;
import interfaz.Ver_compra;

public class Pedidos {
	public Ver_listado_de_compras _ver_listado_de_compras;
	public Vector<Ver_compra> _list_Ver_compra = new Vector<Ver_compra>();
}