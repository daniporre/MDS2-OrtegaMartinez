package interfaz;

public class Crear_nueva_categoria {
	private Label _nombreCategoriaL;
	private TextField _nombreCategoriaTF;
	private Button _crearCategoria;
	public Administrador _administrador;

	public boolean crearCategoria() {
		throw new UnsupportedOperationException();
	}
}