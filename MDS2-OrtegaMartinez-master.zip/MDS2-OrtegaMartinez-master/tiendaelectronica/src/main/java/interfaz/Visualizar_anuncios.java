package interfaz;

public class Visualizar_anuncios {
	private GoogleAdds _anuncio;
	public Usuario_no_registrado _usuario_no_registrado;
	public Clicar_en_anuncio _clicar_en_anuncio;
}