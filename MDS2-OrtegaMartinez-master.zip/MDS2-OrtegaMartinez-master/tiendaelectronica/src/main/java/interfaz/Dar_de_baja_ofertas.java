package interfaz;

public class Dar_de_baja_ofertas {
	private event _dar_de_baja_oferta;
	private Label _titulo;
	private ComboBox _ofertaCB;
	public Administrador _administrador;

	public void Dar_de_baja_oferta() {
		throw new UnsupportedOperationException();
	}
}