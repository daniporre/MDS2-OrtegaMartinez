package interfaz;

public class Ver_forma_de_pago {
	private event _editar_forma_de_pago;
	private TextField _numeroTarjetaTF;
	private Label _titulo;
	private TextField _fechaVencimientoTF;
	private TextField _cvvTF;
	private Button _guardar;
	public Editar_forma_de_pago_y_direccion _editar_forma_de_pago_y_direccion;

	public void Editar_forma_de_pago() {
		throw new UnsupportedOperationException();
	}

	public void guardar() {
		throw new UnsupportedOperationException();
	}
}