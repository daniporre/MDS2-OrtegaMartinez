package interfaz;

public class Validar_cuenta {
	public Crear_cuenta _crear_cuenta;
}