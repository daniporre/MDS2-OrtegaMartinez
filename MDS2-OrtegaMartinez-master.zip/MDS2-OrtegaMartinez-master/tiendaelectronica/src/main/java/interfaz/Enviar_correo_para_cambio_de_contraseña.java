package interfaz;

public class Enviar_correo_para_cambio_de_contraseña {
	public Ver_datos_personales _ver_datos_personales;
	public Correo _enviar_correo_para_cambio_de_contraseña;
}