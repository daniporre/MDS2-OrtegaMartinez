package interfaz;

public class Ver_compra {
	private Label _titulo;
	private Label _fecha;
	private Object _enviadoA;
	private Label _precioTotal;
	private Label _numeroPedido;
	private Image _imagen;
	private Image _imagen2;
	private Image _imagen3;
	private Label _estado;
	public Pedidos _pedidos;
}