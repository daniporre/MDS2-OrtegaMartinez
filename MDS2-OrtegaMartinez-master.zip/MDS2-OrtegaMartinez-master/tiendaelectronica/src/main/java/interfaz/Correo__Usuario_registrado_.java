package interfaz;

public class Correo__Usuario_registrado_ extends Correo__General_ {
	public Ver_cuenta__Usuario_registrado_ _ver_cuenta__Usuario_registrado_;
	public Crear_mensaje _crear_mensaje;
}