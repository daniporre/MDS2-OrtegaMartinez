package interfaz;

public class Marcar_como_no_operativo {
	public Ver_datos_personales _ver_datos_personales;
}