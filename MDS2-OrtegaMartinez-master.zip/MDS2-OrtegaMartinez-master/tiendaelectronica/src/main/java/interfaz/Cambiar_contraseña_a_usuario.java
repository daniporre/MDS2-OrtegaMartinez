package interfaz;

public class Cambiar_contraseña_a_usuario {
	private Label _titulo;
	private Label _seleccionUsuario;
	private ComboBox _usuarioCB;
	private Label _nuevaContraseñaL;
	private TextField _nuevaContraseñaTF;
	private Button _cambiarContraseña;
	public Gestionar_usuarios _gestionar_usuarios;

	public boolean cambiarContraseña() {
		throw new UnsupportedOperationException();
	}
}