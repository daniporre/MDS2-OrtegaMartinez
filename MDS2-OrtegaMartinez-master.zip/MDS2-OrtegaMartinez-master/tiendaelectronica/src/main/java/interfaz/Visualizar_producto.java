package interfaz;

import Diagrama_de_clases_correcto.Valoraciones_del_producto;

public class Visualizar_producto {
	private Image _imagenProducto;
	private Image _imagenProducto2;
	private Image _imagenProducto3;
	private Image _imagenProducto4;
	private Label _nombre;
	private Label _precio;
	private Label _descuento;
	private Image _valoracion;
	private Label _marca;
	private Label _cantidad;
	private ComboBox _cantidadCB;
	private Label _referencia;
	private TextView _descripcion;
	private Button _añadirAlCarrito;
	public Ver_descripción _ver_descripción;
	public Valoraciones_del_producto _valoraciones_del_producto;

	public void añadirAlCarrito() {
		throw new UnsupportedOperationException();
	}
}