package interfaz;

public class Escribir_valoración {
	public Visualizar_pedido _visualizar_pedido;
}