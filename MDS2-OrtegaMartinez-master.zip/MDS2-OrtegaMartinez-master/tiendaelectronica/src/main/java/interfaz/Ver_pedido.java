package interfaz;

public class Ver_pedido {
	public Pedido _pedido;
	public Visualizar_pedido _visualizar_pedido;
}