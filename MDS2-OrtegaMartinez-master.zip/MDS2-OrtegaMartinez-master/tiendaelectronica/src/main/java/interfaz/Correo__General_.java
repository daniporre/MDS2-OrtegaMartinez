package interfaz;

public class Correo__General_ {
	private Button _mensajesRecibidos;
	private Button _mensajesEnviados;
	public Mensajes_enviados _mensajes_enviados;
	public Mensajes_recibidos _mensajes_recibidos;

	public void mostrarMensajesEnviados() {
		throw new UnsupportedOperationException();
	}

	public void mostrarMensajesRecibidos() {
		throw new UnsupportedOperationException();
	}
}