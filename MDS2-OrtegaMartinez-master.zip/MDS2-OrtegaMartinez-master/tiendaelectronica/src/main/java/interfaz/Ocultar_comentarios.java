package interfaz;

public class Ocultar_comentarios {
	public Ver_datos_personales _ver_datos_personales;
}