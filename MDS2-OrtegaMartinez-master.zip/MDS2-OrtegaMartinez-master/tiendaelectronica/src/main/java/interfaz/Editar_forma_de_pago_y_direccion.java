package interfaz;

public class Editar_forma_de_pago_y_direccion {
	public Ver_cuenta__Usuario_registrado_ _ver_cuenta__Usuario_registrado_;
	public Ver_dirección_de_entrega _ver_dirección_de_entrega;
	public Ver_forma_de_pago _ver_forma_de_pago;
}