package interfaz;

import java.util.Vector;
import interfaz.Valoraciones;
import interfaz.Pedido;

public class Ver_pedidos {
	private Label _fecha;
	private Label _referencia;
	private Label _total;
	private Label _estado;
	private Label _titulo;
	public Ver_cuenta__Usuario_registrado_ _ver_cuenta__Usuario_registrado_;
	public Vector<Valoraciones> _list_Valoraciones = new Vector<Valoraciones>();
	public Vector<Pedido> _list_Pedido = new Vector<Pedido>();
}