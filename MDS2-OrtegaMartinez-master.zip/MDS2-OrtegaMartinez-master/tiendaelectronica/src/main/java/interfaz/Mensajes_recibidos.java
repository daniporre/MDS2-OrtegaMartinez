package interfaz;

import java.util.Vector;
import interfaz.Ver_mensaje_recibido;

public class Mensajes_recibidos {
	private Image _estado;
	private Label _cuerpoMensaje;
	private Label _asunto;
	private Label _fecha;
	public Correo__General_ _correo;
	public Vector<Ver_mensaje_recibido> _list_Ver_mensaje_recibido = new Vector<Ver_mensaje_recibido>();
}