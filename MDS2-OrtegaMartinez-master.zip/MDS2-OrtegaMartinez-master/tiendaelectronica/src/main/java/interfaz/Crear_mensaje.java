package interfaz;

public class Crear_mensaje {
	private event _enviar_mensaje;
	private Label _nuevoMensajeTitulo;
	private Label _asuntoL;
	private TexField _asuntoTF;
	private Label _mensajeL;
	private TextView _mensajeTV;
	private Button _cancelar;
	private Button _enviarMensaje;
	public Correo__Usuario_registrado_ _correo__Usuario_registrado_;

	public void Enviar_mensaje() {
		throw new UnsupportedOperationException();
	}

	public void cancelar() {
		throw new UnsupportedOperationException();
	}
}