package interfaz;

public class Común_gestores {
	private Button _cerrarSesionB;
	public Cerrar_sesion__General_ _cerrar_sesion__General_;
	public Ver_listado_de_compras _ver_listado_de_compras;

	public boolean cerrarSesion() {
		throw new UnsupportedOperationException();
	}
}