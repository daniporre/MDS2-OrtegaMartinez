package interfaz;

import java.util.Vector;
import interfaz.Ver_producto_en_carrito;

public class Productos_en_carrito {
	private Label _descripcion;
	private Label _cantidad;
	private Label _precio;
	private Label _subtotal;
	public Ver_carrito _ver_carrito;
	public Vector<Ver_producto_en_carrito> _list_Ver_producto_en_carrito = new Vector<Ver_producto_en_carrito>();
}