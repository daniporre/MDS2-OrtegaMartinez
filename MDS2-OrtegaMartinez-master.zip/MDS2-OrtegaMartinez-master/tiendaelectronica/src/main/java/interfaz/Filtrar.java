package interfaz;

public class Filtrar {
	private event _filtrar_por_precio;
	private event _filtrar_por_marca;
	private Label _filtrarPorPrecio;
	private Label _filtrarPorMarca;
	public Resultado_de_búsqueda _resultado_de_búsqueda;

	public void Filtrar_por_precio() {
		throw new UnsupportedOperationException();
	}

	public void Filtrar_por_marca() {
		throw new UnsupportedOperationException();
	}
}