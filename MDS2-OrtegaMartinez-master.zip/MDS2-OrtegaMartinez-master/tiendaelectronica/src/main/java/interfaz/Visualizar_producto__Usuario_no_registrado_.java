package interfaz;

public class Visualizar_producto__Usuario_no_registrado_ extends Visualizar_producto {
	private event _añadir_al_carrito;
	public Usuario_no_registrado _usuario_no_registrado;

	public void Añadir_al_carrito() {
		throw new UnsupportedOperationException();
	}
}