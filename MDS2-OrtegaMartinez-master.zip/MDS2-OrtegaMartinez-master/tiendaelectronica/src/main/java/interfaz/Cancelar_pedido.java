package interfaz;

public class Cancelar_pedido {
	public Pedido _pedido;
}