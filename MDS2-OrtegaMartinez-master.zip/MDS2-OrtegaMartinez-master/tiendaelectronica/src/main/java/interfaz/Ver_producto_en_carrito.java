package interfaz;

public class Ver_producto_en_carrito {
	private event _disminuir_cantidad_de_producto;
	private event _aumentar_cantidad_de_producto;
	private event _eliminar_producto_del_carrito;
	private Image _imagen;
	private Label _nombreProducto;
	private Label _cantidad;
	private Label _precio;
	private Label _subtotal;
	private Button _eliminarProducto;
	public Productos_en_carrito _productos_en_carrito;

	public void Disminuir_cantidad_de_producto() {
		throw new UnsupportedOperationException();
	}

	public void Aumentar_cantidad_de_producto() {
		throw new UnsupportedOperationException();
	}

	public void Eliminar_producto_del_carrito() {
		throw new UnsupportedOperationException();
	}
}