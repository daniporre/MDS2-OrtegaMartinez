package interfaz;

public class Ver_carrito {
	private Button _continuarComprando;
	public Productos_en_carrito _productos_en_carrito;
	public Continuar_comprando _continuar_comprando;
}