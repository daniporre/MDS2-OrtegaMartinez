package interfaz;

public class Crear_usuario {
	private event _crear;
	private Label _tituloL;
	private Label _correoL;
	private TextField _correoTF;
	private Label _rolL;
	private ComboBox _rolCB;
	private Button _crearUsuarioB;
	public Gestionar_usuarios _gestionar_usuarios;

	public void crearUsuario() {
		throw new UnsupportedOperationException();
	}
}