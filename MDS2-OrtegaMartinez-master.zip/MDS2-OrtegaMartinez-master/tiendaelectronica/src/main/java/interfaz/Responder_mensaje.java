package interfaz;

public class Responder_mensaje {
	public Ver_mensaje_recibido _ver_mensaje_recibido;
}