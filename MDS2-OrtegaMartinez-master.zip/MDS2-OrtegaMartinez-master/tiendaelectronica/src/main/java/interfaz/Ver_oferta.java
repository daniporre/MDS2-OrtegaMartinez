package interfaz;

public class Ver_oferta extends Visualizar_producto {
	private Image _imagen;
	private Label _precio;
	public Ofertas _ofertas;
}