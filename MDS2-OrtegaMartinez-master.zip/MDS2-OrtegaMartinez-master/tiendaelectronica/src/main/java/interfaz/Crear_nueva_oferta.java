package interfaz;

public class Crear_nueva_oferta {
	private Label _nombreOferta;
	private Label _descuento;
	private TextField _nombreOfertaTF;
	private TextField _descuentoTF;
	private Button _crearOferta;
	public Administrador _administrador;
	public Crear_oferta _crear_oferta;

	public boolean crearNuevaOferta() {
		throw new UnsupportedOperationException();
	}
}