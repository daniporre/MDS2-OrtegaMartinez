package interfaz;

public class Enviar_correo {
	public Marcar_pedido_como_recibido _marcar_pedido_como_recibido;
	public Correo _enviar_correo;
}