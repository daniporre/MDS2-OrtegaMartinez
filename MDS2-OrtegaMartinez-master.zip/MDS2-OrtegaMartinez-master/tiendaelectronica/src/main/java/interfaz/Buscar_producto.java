package interfaz;

public class Buscar_producto {
	public Usuario_no_registrado _usuario_no_registrado;
	public Resultado_de_búsqueda _resultado_de_búsqueda;
}