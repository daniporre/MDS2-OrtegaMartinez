package interfaz;

import java.util.Vector;
import interfaz.Ver_categoría;

public class Categorías {
	public Ver_catálogo _ver_catálogo;
	public Vector<Ver_categoría> _list_Ver_categoría = new Vector<Ver_categoría>();
}