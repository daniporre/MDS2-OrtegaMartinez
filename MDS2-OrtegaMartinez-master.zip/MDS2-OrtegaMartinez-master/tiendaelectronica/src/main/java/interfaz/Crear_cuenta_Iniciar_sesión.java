package interfaz;

public class Crear_cuenta_Iniciar_sesión {
	private Panel _iniciarSesion;
	private Panel _crearCuenta;
	public Usuario_no_identificado _usuario_no_identificado;
	public Tramitar_pedido__Usuario_no_registrado_ _tramitar_pedido__Usuario_no_registrado_;
	public Crear_cuenta _crear_cuenta;
	public Iniciar_sesión _iniciar_sesión;
}