package interfaz;

public class Ver_carrito__Usuario_no_registrado_ extends Ver_carrito {
	private Button _tramitarPedido;
	public Usuario_no_registrado _usuario_no_registrado;
	public Tramitar_pedido__Usuario_no_registrado_ _tramitar_pedido__Usuario_no_registrado_;

	public boolean tramitarPedido() {
		throw new UnsupportedOperationException();
	}
}