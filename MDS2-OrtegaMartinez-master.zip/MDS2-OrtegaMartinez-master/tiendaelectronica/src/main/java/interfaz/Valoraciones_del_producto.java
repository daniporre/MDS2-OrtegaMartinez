package Diagrama_de_clases_correcto;

import interfaz.Visualizar_producto;
import java.util.Vector;
import Diagrama_de_clases_correcto.Valoracion_del_producto;

public class Valoraciones_del_producto {
	private Label _tituloValoracionesDelProducto;
	public Visualizar_producto _visualizar_producto;
	public Vector<Valoracion_del_producto> _valoracion_del_producto = new Vector<Valoracion_del_producto>();
}