package interfaz;

public class Ver_dirección_de_entrega {
	private event _editar_dirección_de_entrega;
	private Label _titulo;
	private TextField _calleYNumeroTF;
	private TextField _codigoPostalTF;
	private TextField _ciudadTF;
	private TextField _provinciaTF;
	private Button _guardar;
	public Editar_forma_de_pago_y_direccion _editar_forma_de_pago_y_direccion;

	public void Editar_dirección_de_entrega() {
		throw new UnsupportedOperationException();
	}

	public void guardar() {
		throw new UnsupportedOperationException();
	}
}