package interfaz;

public class Producto_buscado extends Visualizar_producto__Usuario_no_registrado_ {
	private Image _imagen;
	private Label _nombre;
	private Label _precio;
	private Image _valoracion;
	public Productos_buscados _productos_buscados;
}