package interfaz;

public class Ver_datos_personales {
	private event _editar_datos_personales;
	private event _cambiar_contraseña;
	private event _darse_de_baja;
	private Label _titulo;
	private TextField _nombreTF;
	private TextField _mailTF;
	private Button _guardarDatos;
	public Ver_cuenta__Usuario_registrado_ _ver_cuenta__Usuario_registrado_;
	public Enviar_correo_para_cambio_de_contraseña _enviar_correo_para_cambio_de_contraseña;
	public Ocultar_comentarios _ocultar_comentarios;
	public Marcar_como_no_operativo _marcar_como_no_operativo;

	public void Editar_datos_personales() {
		throw new UnsupportedOperationException();
	}

	public void Cambiar_contraseña() {
		throw new UnsupportedOperationException();
	}

	public void Darse_de_baja() {
		throw new UnsupportedOperationException();
	}

	public void marcarComoNoOperativo() {
		throw new UnsupportedOperationException();
	}

	public void ocultarComentarios() {
		throw new UnsupportedOperationException();
	}

	public void guardarDatos() {
		throw new UnsupportedOperationException();
	}
}