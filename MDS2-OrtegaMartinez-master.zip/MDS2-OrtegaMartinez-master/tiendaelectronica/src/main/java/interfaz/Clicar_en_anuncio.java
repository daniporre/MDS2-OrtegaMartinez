package interfaz;

public class Clicar_en_anuncio {
	public Empresa_anunciadora _empresa_anunciadora;
	public Visualizar_anuncios _visualizar_anuncios;
}