package interfaz;

import java.util.Vector;
import interfaz.Ver_oferta;

public class Ofertas {
	private Label _nombreOferta;
	private Button _verMas;
	public Ver_catálogo _ver_catálogo;
	public Vector<Ver_oferta> _list_Ver_oferta = new Vector<Ver_oferta>();
}