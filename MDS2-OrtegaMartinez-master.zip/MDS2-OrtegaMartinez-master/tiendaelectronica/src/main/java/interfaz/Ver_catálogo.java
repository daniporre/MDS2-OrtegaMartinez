package interfaz;

public class Ver_catálogo {
	private Button _carrito;
	private Button _buscarProductos;
	public Común_Usuarios _común_Usuarios;
	public Categorías _categorías;
	public Productos _productos;
	public Ofertas _ofertas;

	public void verCarrito() {
		throw new UnsupportedOperationException();
	}

	public void buscarProducto() {
		throw new UnsupportedOperationException();
	}
}