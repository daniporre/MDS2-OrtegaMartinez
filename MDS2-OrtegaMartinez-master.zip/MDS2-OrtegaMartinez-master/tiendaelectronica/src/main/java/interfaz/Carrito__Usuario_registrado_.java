package interfaz;

public class Carrito__Usuario_registrado_ extends Ver_carrito {
	private Button _tramitarPedido;
	public Usuario_registrado _usuario_registrado;
	public Editar_forma_de_pago_en_carrito _editar_forma_de_pago_en_carrito;
	public Tramitar_pedido__Usuario_Identificado_ _tramitar_pedido__Usuario_Identificado_;

	public boolean tramitarPedido() {
		throw new UnsupportedOperationException();
	}
}