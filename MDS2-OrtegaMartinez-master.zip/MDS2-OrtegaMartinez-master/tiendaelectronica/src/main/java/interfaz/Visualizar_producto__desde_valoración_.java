package interfaz;

public class Visualizar_producto__desde_valoración_ extends Visualizar_producto {
	public Valoración _valoración;
}