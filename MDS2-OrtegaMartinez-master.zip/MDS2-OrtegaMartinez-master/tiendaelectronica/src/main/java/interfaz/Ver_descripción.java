package interfaz;

public class Ver_descripción {
	public Visualizar_producto _visualizar_producto;
}