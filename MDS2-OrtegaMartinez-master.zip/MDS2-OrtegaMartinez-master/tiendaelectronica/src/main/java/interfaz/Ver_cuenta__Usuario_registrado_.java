package interfaz;

public class Ver_cuenta__Usuario_registrado_ {
	private event _cerrar_sesión;
	private Button _correo;
	public Usuario_registrado _usuario_registrado;
	public Valoraciones _valoraciones;
	public Ver_pedidos _ver_pedidos;
	public Editar_forma_de_pago_y_direccion _editar_forma_de_pago_y_direccion;
	public Ver_datos_personales _ver_datos_personales;
	public Correo__Usuario_registrado_ _correo__Usuario_registrado_;

	public void Cerrar_sesión() {
		throw new UnsupportedOperationException();
	}

	public void mostrarCorreo() {
		throw new UnsupportedOperationException();
	}
}