package interfaz;

public class Compra {
	private Button _verFichaUsuario;
	private Button _marcarComoRecibido;
	public Ver_listado_de_compras__Empresa_de_transportes_ _ver_listado_de_compras__Empresa_de_transportes_;
	public Marcar_pedido_como_recibido _marcar_pedido_como_recibido;
	public Ver_ficha_de_usuario _ver_ficha_de_usuario;

	public void marcarPedidoComoRecibido() {
		throw new UnsupportedOperationException();
	}

	public void verFichaUsuario() {
		throw new UnsupportedOperationException();
	}
}