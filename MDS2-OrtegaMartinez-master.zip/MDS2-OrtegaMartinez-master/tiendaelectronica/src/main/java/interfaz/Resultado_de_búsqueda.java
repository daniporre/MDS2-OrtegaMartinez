package interfaz;

public class Resultado_de_búsqueda {
	private event _ordenar_productos;
	public Buscar_producto _buscar_producto;
	public Productos_buscados _productos_buscados;
	public Filtrar _filtrar;

	public void Ordenar_productos() {
		throw new UnsupportedOperationException();
	}
}