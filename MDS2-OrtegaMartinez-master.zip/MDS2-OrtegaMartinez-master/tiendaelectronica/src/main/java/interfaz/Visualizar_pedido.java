package interfaz;

public class Visualizar_pedido {
	private Label _fecha;
	private Label _enviadoA;
	private Label _numeroPedido;
	private Label _nombreProducto;
	private Label _precio;
	private Image _imagen;
	private TextView _comentario;
	private Button _valorar;
	public Ver_pedido _ver_pedido;
	public Escribir_valoración _escribir_valoración;

	public void valorarProducto() {
		throw new UnsupportedOperationException();
	}
}