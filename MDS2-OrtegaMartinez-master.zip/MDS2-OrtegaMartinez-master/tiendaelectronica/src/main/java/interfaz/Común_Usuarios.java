package interfaz;

import basededatos.iComún_Usuarios;

public class Común_Usuarios {
	public iComún_Usuarios _iComún_Usuarios;
	public Ver_catálogo _ver_catálogo;
}