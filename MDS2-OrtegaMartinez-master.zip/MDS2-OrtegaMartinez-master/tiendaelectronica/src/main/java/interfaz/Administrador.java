package interfaz;

import basededatos.iAdministrador;

public class Administrador extends Común_Usuarios {
	public iAdministrador _iAdministrador;
	public Modificar_producto _modificar_producto;
	public Gestionar_usuarios _gestionar_usuarios;
	public Añadir_producto _añadir_producto;
	public Correo__Administrador_ _correo__Administrador_;
	public Crear_nueva_oferta _crear_nueva_oferta;
	public Dar_de_baja_ofertas _dar_de_baja_ofertas;
	public Ver_listado_de_compras__Administrador_ _ver_listado_de_compras__Administrador_;
	public Crear_nueva_categoria _crear_nueva_categoria;
}