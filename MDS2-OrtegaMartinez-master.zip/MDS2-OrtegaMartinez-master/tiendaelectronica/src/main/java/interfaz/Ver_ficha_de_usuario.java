package interfaz;

public class Ver_ficha_de_usuario {
	public Compra _compra;
	public Visualizar_ficha_de_usuario _visualizar_ficha_de_usuario;
}