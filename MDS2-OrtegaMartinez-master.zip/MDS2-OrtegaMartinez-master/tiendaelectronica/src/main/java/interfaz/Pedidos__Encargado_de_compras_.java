package interfaz;

import java.util.Vector;
import interfaz.Compra_Encargado_de_compras_;

public class Pedidos__Encargado_de_compras_ {
	public Ver_listado_de_compras__Encargado_de_compras_ _ver_listado_de_compras__Encargado_de_compras_;
	public Vector<Compra_Encargado_de_compras_> _list_Compra_Encargado_de_compras_ = new Vector<Compra_Encargado_de_compras_>();
}