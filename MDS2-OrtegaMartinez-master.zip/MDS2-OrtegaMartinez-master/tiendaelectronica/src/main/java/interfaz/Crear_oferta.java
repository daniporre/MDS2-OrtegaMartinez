package interfaz;

public class Crear_oferta {
	public Crear_nueva_oferta _crear_nueva_oferta;
}