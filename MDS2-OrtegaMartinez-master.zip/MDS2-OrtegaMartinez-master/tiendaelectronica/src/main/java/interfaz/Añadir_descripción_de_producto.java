package interfaz;

public class Añadir_descripción_de_producto {
	private event _guardar_cambios__Añadir_producto_;
	public Añadir_producto _añadir_producto;

	public void Guardar_cambios__Añadir_producto_() {
		throw new UnsupportedOperationException();
	}
}