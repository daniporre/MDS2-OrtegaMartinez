package interfaz;

public class Modificar_producto {
	private ImageButton _imagen;
	private ImageButton _imagen2;
	private ImageButton _imagen3;
	private ImageButton _imagen4;
	private Label _titulo;
	private Label _precio;
	private Image _valoracion;
	private Label _marca;
	private Label _referencia;
	private Label _seleccionarOferta;
	private ComboBox _seleccionarOfertaCB;
	private Button _guardarCambios;
	private Label _descripcionL;
	private TextView _descripcionTV;
	public Administrador _administrador;
	public Modificar_datos _modificar_datos;
	public Seleccionar_oferta__Modificar_producto_ _seleccionar_oferta__Modificar_producto_;

	public void añadirImagen1() {
		throw new UnsupportedOperationException();
	}

	public void añadirImagen2() {
		throw new UnsupportedOperationException();
	}

	public void añadirImagen3() {
		throw new UnsupportedOperationException();
	}

	public void añadirImagen4() {
		throw new UnsupportedOperationException();
	}

	public void guardarCambios() {
		throw new UnsupportedOperationException();
	}
}