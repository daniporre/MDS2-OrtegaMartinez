package interfaz;

import java.util.Vector;
import interfaz.Valoración;

public class Valoraciones {
	private Label _valoraciones;
	public Ver_pedidos _ver_pedidos;
	public Ver_cuenta__Usuario_registrado_ _ver_cuenta__Usuario_registrado_;
	public Vector<Valoración> _list_Valoración = new Vector<Valoración>();
}