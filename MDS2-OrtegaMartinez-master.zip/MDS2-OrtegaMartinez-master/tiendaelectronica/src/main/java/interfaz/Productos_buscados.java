package interfaz;

import java.util.Vector;
import interfaz.Producto_buscado;

public class Productos_buscados {
	private Label _resultadosBusqueda;
	public Resultado_de_búsqueda _resultado_de_búsqueda;
	public Vector<Producto_buscado> _list_Producto_buscado = new Vector<Producto_buscado>();
}