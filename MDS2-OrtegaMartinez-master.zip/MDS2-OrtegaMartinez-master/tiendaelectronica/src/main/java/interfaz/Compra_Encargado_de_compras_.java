package interfaz;

public class Compra_Encargado_de_compras_ {
	private event _enviar_pedido;
	public Pedidos__Encargado_de_compras_ _pedidos__Encargado_de_compras_;
	public Enviar_correo_de_confirmacion _enviar_correo_de_confirmacion;

	public void Enviar_pedido() {
		throw new UnsupportedOperationException();
	}

	public boolean enviarCorreoConfirmacion() {
		throw new UnsupportedOperationException();
	}
}