package interfaz;

public class Correo_de_verificación {
	public Recuperar_contraseña _recuperar_contraseña;
	public Correo _correo_de_verificación;
}