package interfaz;

public class Marcar_pedido_como_recibido {
	public Compra _compra;
	public Enviar_correo _enviar_correo;

	public boolean enviarCorreoConfirmacion() {
		throw new UnsupportedOperationException();
	}
}