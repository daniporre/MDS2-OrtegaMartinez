package interfaz;

public class Enviar_correo_de_confirmación {
	public Correo _correo;
	public Tramitar_pedido__Usuario_Identificado_ _tramitar_pedido__Usuario_Identificado_;
}