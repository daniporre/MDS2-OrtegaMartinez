package interfaz;

public class Ver_listado_de_compras__Administrador_ extends Común_gestores {
	public Administrador _administrador;
}