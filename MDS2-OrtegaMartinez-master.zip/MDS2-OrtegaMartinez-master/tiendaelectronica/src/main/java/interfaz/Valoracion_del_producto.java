package Diagrama_de_clases_correcto;

public class Valoracion_del_producto {
	private Label _nombreUsuario;
	private Image _valoracionProducto;
	private TextView _comentarioValoracion;
	public Valoraciones_del_producto _valoraciones_del_producto;
}