package interfaz;

import basededatos.iUsuario_registrado;

public class Usuario_registrado extends Usuario_no_registrado {
	public iUsuario_registrado _iUsuario_registrado;
	public Ver_cuenta__Usuario_registrado_ _ver_cuenta__Usuario_registrado_;
	public Carrito__Usuario_registrado_ _carrito__Usuario_registrado_;
}