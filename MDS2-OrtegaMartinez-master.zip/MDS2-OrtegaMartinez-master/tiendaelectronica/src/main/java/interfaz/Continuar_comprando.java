package interfaz;

public class Continuar_comprando {
	public Ver_carrito _ver_carrito;

	public void mostrarCatalogoInicial() {
		throw new UnsupportedOperationException();
	}
}