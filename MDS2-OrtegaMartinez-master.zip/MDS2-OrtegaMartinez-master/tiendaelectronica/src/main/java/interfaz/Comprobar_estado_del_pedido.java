package interfaz;

public class Comprobar_estado_del_pedido {
	public Pedido _pedido;
}