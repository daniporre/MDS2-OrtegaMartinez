package interfaz;

public class Ver_producto extends Visualizar_producto {
	private Image _imagenProducto;
	private Label _nombre;
	private Label _descripcion;
	public Productos _productos;
}