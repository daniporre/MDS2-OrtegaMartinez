package interfaz;

public class Visualizar_ficha_de_usuario {
	private Label _titulo;
	private Label _nombre;
	private Label _nombreUsuario;
	private Label _direccion;
	private Label _calle;
	private Label _codigoPostal;
	private Label _numero;
	private Label _ciudad;
	private Label _provincia;
	private Button _atrasB;
	private Image _logo;
	public Ver_ficha_de_usuario _ver_ficha_de_usuario;

	public void atras() {
		throw new UnsupportedOperationException();
	}
}