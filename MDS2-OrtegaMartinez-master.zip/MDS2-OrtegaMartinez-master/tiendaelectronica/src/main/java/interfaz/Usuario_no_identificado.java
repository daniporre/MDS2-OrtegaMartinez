package interfaz;

import basededatos.iUsuario_no_identificado;

public class Usuario_no_identificado extends Usuario_no_registrado {
	public iUsuario_no_identificado _iUsuario_no_identificado;
	public Crear_cuenta_Iniciar_sesión _crear_cuenta_Iniciar_sesión;
}