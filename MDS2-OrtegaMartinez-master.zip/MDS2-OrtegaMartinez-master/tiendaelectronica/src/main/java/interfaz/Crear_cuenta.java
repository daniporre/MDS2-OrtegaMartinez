package interfaz;

public class Crear_cuenta {
	private Label _titulo;
	private Label _mail;
	private Label _contraseña;
	private TextField _mailTF;
	private TextField _contraseñaTF;
	private Button _crearCuentaB;
	public Crear_cuenta_Iniciar_sesión _crear_cuenta_Iniciar_sesión;
	public Validar_cuenta _validar_cuenta;

	public void validarCuenta() {
		throw new UnsupportedOperationException();
	}

	public void crearCuenta() {
		throw new UnsupportedOperationException();
	}
}